using UdpServerPropagation;
using System.Text.Json;
using System.Threading;
using WebSocketSharp;

namespace TeamProject;

public class Client
{
    public static void Run()
    {
        List<UdpData> foundServers = new();
        AutoResetEvent foundEvent = new(false);

        var discover = new DiscoverAvaiableServers(10000, msg =>
        {
            try
            {
                var data = JsonSerializer.Deserialize<UdpData>(msg);
                if (data != null && !foundServers.Any(s => s.ID == data.ID))
                {
                    foundServers.Add(data);
                    Console.WriteLine($"Znaleziono serwer: {data.serverChatName} na porcie {data.serverChatPort}");
                    foundEvent.Set();
                }
            }
            catch { }
        });
        discover.Start();

        Console.WriteLine("Szukam serwer�w w sieci (czekam na pierwszy broadcast)...");
        foundEvent.WaitOne(3000);

        if (foundServers.Count == 0)
        {
            Console.WriteLine("Nie znaleziono serwer�w!");
            return;
        }

        var server = foundServers[0];
        if (foundServers.Count > 1)
        {
            Console.WriteLine("Wybierz serwer:");
            for (int i = 0; i < foundServers.Count; i++)
                Console.WriteLine($"{i + 1}. {foundServers[i].serverChatName} (port {foundServers[i].serverChatPort})");
            int idx = int.Parse(Console.ReadLine() ?? "1") - 1;
            server = foundServers[idx];
        }

        Console.Write("Your login: ");
        var name = Console.ReadLine();
        Console.Write("Your password: ");
        var password = Console.ReadLine();

        using var webSocket = new WebSocket($"ws://localhost:{server.serverChatPort}/chat");
        webSocket.OnMessage += (_, e) => Console.WriteLine(e.Data);
        webSocket.Connect();
        webSocket.Send($"{name}:{password}");

        while (true)
        {
            var message = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(message)) continue;
            webSocket.Send(message);
        }
    }
}
