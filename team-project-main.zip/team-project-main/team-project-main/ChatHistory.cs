using System.Text.Json;

namespace TeamProject;

public class ChatMessage
{
	public string User { get; set; } = "";
	public string Message { get; set; } = "";
	public DateTime Timestamp { get; set; }
}

public class ChatHistory
{
	private const string HistoryFile = "chat_history.json";
	private List<ChatMessage> _messages = new();

	public ChatHistory()
	{
		if (File.Exists(HistoryFile))
		{
			var json = File.ReadAllText(HistoryFile);
			var loaded = JsonSerializer.Deserialize<List<ChatMessage>>(json);
			if (loaded != null) _messages = loaded;
		}
	}

	public void AddMessage(string user, string message)
	{
		var msg = new ChatMessage
		{
			User = user,
			Message = message,
			Timestamp = DateTime.Now
		};
		_messages.Add(msg);
		Save();
	}

	public IEnumerable<ChatMessage> GetLastMessages(int count = 20)
		=> _messages.TakeLast(count);

	private void Save()
	{
		var json = JsonSerializer.Serialize(_messages, new JsonSerializerOptions { WriteIndented = true });
		File.WriteAllText(HistoryFile, json);
	}
}
