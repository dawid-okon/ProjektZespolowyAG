using UdpServerPropagation;
using WebSocketSharp.Server;
using System.Net;

namespace TeamProject;

public class ChatBehavior : WebSocketBehavior
{
    private static readonly ChatHistory History = new();
    private static readonly Authentication Auth = new();
    private string? _userName;

    protected override void OnMessage(WebSocketSharp.MessageEventArgs e)
    {
        if (_userName == null)
        {
            var credentials = e.Data.Split(':');
            if (credentials.Length != 2)
            {
                Send("Invalid credentials format. Use login:password");
                return;
            }
            var resp = Auth.SignIn(credentials[0], credentials[1]);
            Send(resp.Message);
            if (!resp.Success)
            {
                Context.WebSocket.Close();
                return;
            }
            _userName = credentials[0];
            foreach (var msg in History.GetLastMessages())
                Send($"{msg.Timestamp:HH:mm} {msg.User}: {msg.Message}");
            return;
        }
        History.AddMessage(_userName, e.Data);
        Sessions.Broadcast($"{DateTime.Now:HH:mm} {_userName}: {e.Data}");
    }
}

public class Server
{
    public static void Run()
    {
        // Start propagacji UDP (port discovery 10000, port czatu 2137)
        var udpPropagation = new ServerPropagationProcess(10000, "ChatServer", 2137);
        udpPropagation.Start();

        var wssv = new WebSocketServer(IPAddress.Any, 2137);
        wssv.AddWebSocketService<ChatBehavior>("/chat");
        Console.WriteLine("Serwer wystartowa� na ws://localhost:2137/chat");
        wssv.Start();
        Console.WriteLine("Naci�nij Enter, aby zako�czy�...");
        Console.ReadLine();
        wssv.Stop();
    }
}
