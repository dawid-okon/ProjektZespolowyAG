namespace UdpServerPropagation
{
    public class UdpData
    {
        public string serverChatName { get; set; }
        public int serverChatPort { get; set; }
        public Guid ID { get; set; } = Guid.NewGuid();
    }
}
